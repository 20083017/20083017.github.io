#!/bin/bash
new_ip=192.168.31.164
brd=192.168.31.255
gateway=192.168.31.1
nameserver=192.168.31.1
net_dev=eth0
echo "password" | sudo -S ip addr del $(ip addr show $net_dev | grep 'inet\b' | awk '{print $2}' | head -n 1) dev $net_dev
sudo ip addr add $new_ip/24 broadcast $brd dev $net_dev
sudo ip route add 0.0.0.0/0 via $gateway dev $net_dev
sudo sed -i "\$c nameserver $nameserver" /etc/resolv.conf



# sudo ip addr del $(ip addr show eth0 | grep 'inet\b' | awk '{print $2}' | head -n 1) dev eth0
# sudo ip addr add 192.168.31.164/24 broadcast 192.168.31.255 dev eth0
# sudo ip route add 0.0.0.0/0 via 192.168.31.1 dev eth0
